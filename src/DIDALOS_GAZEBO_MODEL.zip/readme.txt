1. DIDALOS_vtol (model folder)
/home/user/PX4-Autopilot/Tools/simulation/gazebo-classic/sitl_gazebo-classic/models

p.s. if you specified the YOURWORLD file in sdf file of model folder, it will be launched to a YOUR WORLD. if you didn't, it will be launched 'empty.world'


2. 1046_gazebo-classic_DIDALOS_vtol (PX4 parameter file, this file was linked the DIDALOS model with same file name)
/home/user/PX4-Autopilot/ROMFS/px4fmu_common/init.d-posix/airframes

and add your parameter file name in the CMakeLists.txt of folder 'airframes'


3. sitl_targets_gazebo-classic.cmake (if your PX4-Autopilot version is lastest, this file is already exist. you can add your gazebo model folder name by just edit file.)
/home/user/PX4-Autopilot/src/modules/simulation/simulator_mavlink



---------------------------------
my developing environment
- ubuntu 20.04
- ROS noetic
- PX4-Autopilot 1.15.0 (lastest)
- gazebo11 (same to gazebo-classic)


Park S.H.
neonstars@o.cnu.ac.kr

